# Assignment HelloWorld - Workflow of the exercises.

Traditionally, the first exercise when learning a programming language is a Hello World application. In this exercise, we have already provided this code for you, and you only have to make a small modification. So the exercise focuses mainly on trying how the exercises work. You can find this "Workflow" written out in detail on Blackboard.

## Functionality of application

The code should satisfy the following functionalities:

Print a message "Hello world from <Your name>" in the command prompt.

## Learning objectives of exercise

- To try out the workflow of the exercises:

    - Getting to know Bitbucket and Git by creating a fork
    - Editing code in an editor
    - Compile and test code via Maven test
    - Submit exercise via Git
