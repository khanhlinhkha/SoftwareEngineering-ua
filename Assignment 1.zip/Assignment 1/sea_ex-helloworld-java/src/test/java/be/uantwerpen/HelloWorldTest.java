package be.uantwerpen;

import org.junit.Assert;
import org.junit.Test;

public class HelloWorldTest {
    @Test
    public void testGreeting() {
        // ARRANGE
        // no arrange required, testing static method

        // ACT 
        String message = HelloWorld.getMessage();

        // ASSERT
        Assert.assertEquals("Hello world from", message.substring(0, "Hello world from".length()));
    }
}
