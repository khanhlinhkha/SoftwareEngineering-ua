package be.uantwerpen;

public class HelloWorld { //Class definition

    public static void main(String[] args) {
        // The next line currently prints "Hello, World" in the command line interface
        System.out.println(getMessage());
    }

    public static String getMessage() {
        return "Hello world from Khanh Linh Kha"; // Edit this line so it prints "Hello world from <your name >" 
    }

}